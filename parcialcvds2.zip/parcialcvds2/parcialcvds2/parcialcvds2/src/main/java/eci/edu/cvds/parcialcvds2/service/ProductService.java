package com.cvds.parcial.service;

import com.cvds.parcial.models.Product;
import com.cvds.parcial.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Servicio de productos
 */
@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    /**
     * Guarda un producto en la base de datos
     * @param product producto a guardar
     * @return producto guardado
     */
    public Product save(Product product) {
        return productRepository.save(product);
    }

    /**
     * Obtiene un producto por su id
     * @param id id del producto
     * @return producto
     */
    public Product getProductById(String id) {
        return productRepository.findById(id).orElse(null);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }
}
