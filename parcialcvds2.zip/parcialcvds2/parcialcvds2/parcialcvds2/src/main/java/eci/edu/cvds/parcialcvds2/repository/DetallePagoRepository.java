package com.cvds.parcial.repository;

import com.cvds.parcial.models.DetallePago;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DetallePagoRepository extends MongoRepository<DetallePago, Integer> {
}
