package eci.edu.cvds.parcialcvds2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Parcialcvds2Application {

	public static void main(String[] args) {
		SpringApplication.run(Parcialcvds2Application.class, args);
	}

}
