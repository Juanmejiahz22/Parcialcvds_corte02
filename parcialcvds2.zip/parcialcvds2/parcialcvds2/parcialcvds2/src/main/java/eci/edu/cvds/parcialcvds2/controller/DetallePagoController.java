package com.cvds.parcial.controller;

import com.cvds.parcial.models.DetallePago;
import com.cvds.parcial.service.DetallePagoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1.0/detalle-pago")
public class DetallePagoController {
    @Autowired
    private DetallePagoService detallePagoService;

    @PostMapping("/save")
    private DetallePago save(@RequestBody DetallePago detallePago){
        return detallePagoService.save(detallePago);
    }


}
