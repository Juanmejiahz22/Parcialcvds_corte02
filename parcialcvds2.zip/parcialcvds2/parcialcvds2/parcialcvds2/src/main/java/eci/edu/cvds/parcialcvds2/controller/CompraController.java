package com.cvds.parcial.controller;

import com.cvds.parcial.models.Compra;
import com.cvds.parcial.service.CompraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1.0/compra")
public class CompraController {

    @Autowired
    private CompraService compraService;

    @GetMapping("/all")
    public ResponseEntity<?> getDetallePago() {
        return ResponseEntity.ok(compraService.getDetallePago());
    }

    @PostMapping("/save")
    public ResponseEntity<?> save(@RequestBody Compra compra) {
        try{
            Map<String, String> mesage = new HashMap<>();
            Compra compraToSave = compraService.save(compra);
            mesage.put("mensaje", compraToSave.toString());
            mesage.put("status", "Aceptado");
            return ResponseEntity.ok(compraToSave);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            error.put("status", "Declinado");
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> findById(@PathVariable int id) {
        return ResponseEntity.ok(compraService.findById(id));
    }


}
