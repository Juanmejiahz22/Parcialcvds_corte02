package com.cvds.parcial.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Document(collection = "compras")
public class Compra {
    @Id
    private int idCompra;
    private List<DetallePago> detallePago;
    private double total;

    public Compra() {
        this.detallePago = new ArrayList<>();
    }

    public Compra(int idCompra, List<DetallePago> detallePago) {
        this.idCompra = idCompra;
        this.detallePago = new ArrayList<>(detallePago); // Evita modificar la lista original
        recalcularTotal();
    }

    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public List<DetallePago> getDetallePago() {
        return new ArrayList<>(detallePago); // Evita modificaciones directas
    }

    public void setDetallePago(List<DetallePago> detallePago) {
        this.detallePago = new ArrayList<>(detallePago);
        recalcularTotal();
    }

    public double getTotal() {
        return total;
    }

    // Método para recalcular el total basado en los DetallePago
    private void recalcularTotal() {
        this.total = detallePago.stream().mapToDouble(DetallePago::getTotal).sum();
    }
}


