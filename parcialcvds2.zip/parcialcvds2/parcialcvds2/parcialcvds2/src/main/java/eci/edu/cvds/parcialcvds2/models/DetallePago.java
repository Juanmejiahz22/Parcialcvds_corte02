package com.cvds.parcial.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = "detallePago")
public class DetallePago {
    public DetallePago(Integer id, Product product, Double valor, Date fecha, int cantidad) {
        this.id = id;
        this.product = product;
        this.valor = valor;
        this.fecha = fecha;
        this.cantidad = cantidad;
        this.total = cantidad * valor;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public DetallePago() {
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Id
    private Integer id;
    private Product product;
    private Double valor;
    private Date fecha;
    private int cantidad;
    private Double total;

    public void setTotal(Double cantidadTotal) {
        this.total = cantidadTotal;
    }

    public Double getTotal() {
        return total;
    }
}

