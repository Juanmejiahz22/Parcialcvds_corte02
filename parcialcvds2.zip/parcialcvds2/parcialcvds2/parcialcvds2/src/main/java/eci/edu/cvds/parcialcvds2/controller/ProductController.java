package com.cvds.parcial.controller;
 
import com.cvds.parcial.models.Product;
import com.cvds.parcial.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 
import java.util.List;
 
@RestController
@RequestMapping("/api/v1.0/product")
public class ProductController {
 
    @Autowired
    private ProductService productService;
 
    @PostMapping("/save")
    public ResponseEntity<Product> save(@RequestBody Product product) {
return ResponseEntity.ok(productService.save(product));
    }
 
    @GetMapping("/{id}")
    public ResponseEntity<Product> findById(@PathVariable String id) {
        return ResponseEntity.ok(productService.getProductById(id));
    }
 
    @GetMapping("/all")
    public ResponseEntity<List<Product>> findAll() {
        return ResponseEntity.ok(productService.getAllProducts());
    }
}
