package com.cvds.parcial.service;

import com.cvds.parcial.models.Compra;
import com.cvds.parcial.models.DetallePago;
import com.cvds.parcial.repository.CompraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompraService {

    @Autowired
    private CompraRepository compraRepository;

    public Compra save(Compra compra) {
        List<DetallePago> detallePagos = compra.getDetallePago();
        Double total = compra.getTotal();
        Double pricetotal = 0.0;
        for (DetallePago detallePago : detallePagos) {
            pricetotal += detallePago.getTotal();
        }
        if (!pricetotal.equals(total)) {
            throw new RuntimeException("El total no coincide con la suma de los productos");
        }

        return compraRepository.save(compra);
    }

    public List<Compra> getDetallePago() {
        return compraRepository.findAll();
    }


    public Compra findById(int id) {
        return compraRepository.findById(id).orElse(null);
    }
}
