package com.cvds.parcial.repository;

import com.cvds.parcial.models.Compra;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompraRepository extends MongoRepository<Compra, Integer> {
}
