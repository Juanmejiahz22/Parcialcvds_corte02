package com.cvds.parcial.service;


import com.cvds.parcial.models.DetallePago;
import com.cvds.parcial.repository.DetallePagoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DetallePagoService {

    @Autowired
    private DetallePagoRepository detallePagoRepository;

    public DetallePago save(DetallePago detallePago){
        Double cantidadTotal = detallePago.getCantidad() * detallePago.getValor();
        detallePago.setTotal(cantidadTotal);
        return detallePagoRepository.save(detallePago);
    }

    public DetallePago findById(Integer id){
        return detallePagoRepository.findById(id).orElse(null);
    }
}
