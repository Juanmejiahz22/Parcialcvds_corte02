package com.cvds.parcial.service;

import com.cvds.parcial.models.Compra;
import com.cvds.parcial.models.DetallePago;
import com.cvds.parcial.repository.CompraRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CompraServiceTest {

    @Mock
    private CompraRepository compraRepository;

    @InjectMocks
    private CompraService compraService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveCompra_Valida() {
        DetallePago detalle = new DetallePago(1, null, 100.0, null, 2); // Total: 200.0
        Compra compra = new Compra(1, List.of(detalle));
        
        when(compraRepository.save(compra)).thenReturn(compra);

        Compra result = compraService.save(compra);

        assertNotNull(result);
        assertEquals(1, result.getIdCompra());
    }

    @Test
    void testFindById() {
        Compra compra = new Compra(1, List.of());
        when(compraRepository.findById(1)).thenReturn(Optional.of(compra));

        Compra result = compraService.findById(1);

        assertNotNull(result);
        assertEquals(1, result.getIdCompra());
    }

    @Test
    void testGetDetallePago() {
        when(compraRepository.findAll()).thenReturn(List.of(new Compra(1, List.of())));

        List<Compra> compras = compraService.getDetallePago();

        assertEquals(1, compras.size());
    }
}
