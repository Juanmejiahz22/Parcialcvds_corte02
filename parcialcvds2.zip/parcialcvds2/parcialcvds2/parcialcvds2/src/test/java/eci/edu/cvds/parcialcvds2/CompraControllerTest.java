package com.cvds.parcial.controller;
 
import com.cvds.parcial.models.Compra;
import com.cvds.parcial.service.CompraService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
 
import java.util.Arrays;
import java.util.List;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
 
class CompraControllerTest {
 
    @InjectMocks
    private CompraController compraController;
 
    @Mock
    private CompraService compraService;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
 
    @Test
    void testGetDetallePago() {
        Compra compra1 = new Compra();
        Compra compra2 = new Compra();
        List<Compra> compras = Arrays.asList(compra1, compra2);
        
        when(compraService.getDetallePago()).thenReturn(compras);
        
        ResponseEntity<?> response = compraController.getDetallePago();
        
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(compras, response.getBody());
    }
 
    @Test
    void testFindById() {
        int id = 1;
        Compra compra = new Compra();
        
        when(compraService.findById(id)).thenReturn(compra);
        
        ResponseEntity<?> response = compraController.findById(id);
        
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(compra, response.getBody());
    }
}
 