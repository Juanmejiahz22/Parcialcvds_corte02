package com.cvds.parcial.service;

import com.cvds.parcial.models.DetallePago;
import com.cvds.parcial.repository.DetallePagoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class DetallePagoServiceTest {

    @Mock
    private DetallePagoRepository detallePagoRepository;

    @InjectMocks
    private DetallePagoService detallePagoService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveDetallePago() {
        DetallePago detallePago = new DetallePago(1, null, 100.0, null, 2); // Total: 200.0
        
        when(detallePagoRepository.save(any(DetallePago.class))).thenReturn(detallePago);

        DetallePago result = detallePagoService.save(detallePago);

        assertNotNull(result);
        assertEquals(200.0, result.getTotal());
    }

    @Test
    void testFindById() {
        DetallePago detallePago = new DetallePago(1, null, 100.0, null, 2);
        when(detallePagoRepository.findById(1)).thenReturn(Optional.of(detallePago));

        DetallePago result = detallePagoService.findById(1);

        assertNotNull(result);
        assertEquals(1, result.getId());

    }
}
