package com.cvds.parcial.tests;

import com.cvds.parcial.models.Compra;
import com.cvds.parcial.models.DetallePago;
import org.junit.jupiter.api.Test;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CompraTest {

    @Test
    void testCrearCompra() {
        // Crear una compra vacía
        Compra compra = new Compra(1, List.of());

        // Verificar que el ID es correcto y que el total es 0
        assertEquals(1, compra.getIdCompra());
        assertEquals(0.0, compra.getTotal());
    }

    @Test
    void testModificarCompra() {
        Compra compra = new Compra(2, List.of());

        // Cambiar el ID de la compra
        compra.setIdCompra(5);

        // Verificar que el ID se actualizó correctamente
        assertEquals(5, compra.getIdCompra());
    }

    @Test
    void testCompraSinDetalle() {
        Compra compra = new Compra(3, List.of());

        // Verificar que el total sigue siendo 0
        assertEquals(0.0, compra.getTotal());
        assertTrue(compra.getDetallePago().isEmpty());
    }
}





